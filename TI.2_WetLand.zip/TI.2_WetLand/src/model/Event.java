package model;

public class Event {
	//atributos
	private String name;
	private EventType type;
	private String organizer;
	private double value;
	private String description;
	
	//relacion
	private Date date;
	
	//modulos
	public enum EventType{
		MAINTENANCE,
		SCHOOLVISIT,
		IMPROVEMENT,
		CELEBRATION
	}
	
	public Event(String name, int t, int d, int m, int y, String organizer, double value, String description) {
		this.name=name;
		this.date=new Date(d,m,y);
		this.organizer=organizer;
		this.value=value;
		this.description=description;
		
		switch(t) {
		case 1:
			this.type=EventType.MAINTENANCE;
			break;
		case 2:
			this.type=EventType.SCHOOLVISIT;
			break;
		case 3:
			this.type=EventType.IMPROVEMENT;
			break;
		case 4:
			this.type=EventType.CELEBRATION;
			break;
			
		}
		
	}
	
	public String getName() {
		return name;
		}
		
	public void setName(String name) {
		this.name = name;
	    }
	
	public String getType() {
		return type.toString();
		}
		
	public void setType(EventType type) {
		this.type = type;
	    }
	
	public String getOrganizer() {
		return organizer;
		}
		
	public void setOrganizer(String organizer) {
		this.organizer = organizer;
	    }
	
	public double getValue() {
		return value;
		}
		
	public void setValue(double value) {
		this.value = value;
	    }
	
	public String getDescription() {
		return description;
		}
		
	public void setDescription(String description) {
		this.description = description;
	    }
	
	public Date getDate() {
		return date;
		}
		
	public void setDate(int d, int m, int y) {
		this.date = new Date(d, m, y);
	    }

}
