package model;
import java.util.*;

public class Town {
	public static final int MAXWETLANDS=100;
	
	//relaciones
	private static Wetland[] wetlands;
	
	//modulos
	public Town() {
		Town.wetlands=new Wetland[MAXWETLANDS];
	}
	
	public boolean existWetland(String name){
		boolean resultado=false;
		for(int i=0;i<MAXWETLANDS && resultado==false; i++){
			if(wetlands[i]!=null && wetlands[i].getName().equals(name))
				resultado=true;
			}
		return resultado;
	   }
	
	public String addWetland(String name, boolean urban, String location, boolean publ, double surface, String picture, boolean protect){
		boolean continuar=true;
	    String message="Wetland registered correctly";
	    boolean exist=existWetland(name);
	    if (exist==true)
	       message="This wetland already exists.";
	    else
	    {
	      for (int i=0;(i<MAXWETLANDS) && continuar;i++){
	        if (wetlands[i]==null){
	        	wetlands[i]=new Wetland(name,urban,location,publ, surface, picture, protect);
	           continuar=false;}
	      }
	      if(continuar==true)
	         message="Array of wetlands is full";
	    }
	    return message;
	   }
	
	public static Wetland[] getWetlands() {
		return wetlands;
		}
		
	public void setWetlands(Wetland[] wetlands) {
		Town.wetlands = wetlands;
	    }
	
	public String newSpecies(String wetlandSpecies, String name, String scname, boolean mig, int t) {
		String mens="";
		for(int i=0;i<wetlands.length; i++){
			if(wetlands[i].getName().equals(wetlandSpecies)) {
				mens = Wetland.addSpecies(name, scname, mig, t);
			}
		}
		return mens;
	}
	
	public String newEvent(String wetlandEvent, String name, int type, int day, int month, int year, String organizer, double value, String description) {
		String mens="";
		for(int i=0;i<wetlands.length; i++){
			if(wetlands[i].getName().equals(wetlandEvent)) {
				mens = Wetland.addEvent(name, type, day, month, year, organizer, value, description);
			}
		}
		return mens;
	}
	
	public static String countAllMaint(int y) {
		String mens="";
		ArrayList<String>wetlandsNames = new ArrayList<String>();
		ArrayList<Integer>countMaint = new ArrayList<Integer>();
		for (int i=0; (i<=wetlands.length); i++){
			wetlandsNames.add(wetlands[i].getName());
			countMaint.add(Wetland.countMaint(y));
		}		mens="For wetlands "+wetlandsNames+ ", there were respectively "+countMaint+"maintenance operations occurred in "+y+"." ;
		return mens;
	}
	
	public static String infoAllWetlands() {
		String mens="";
		ArrayList<String>wetlandsNames = new ArrayList<String>();
		ArrayList<String>info = new ArrayList<String>();
		for (int i=0; (i<=wetlands.length); i++){
			wetlandsNames.add(wetlands[i].getName());
			info.add(Wetland.infoWetland(wetlands[i]));
		}
		mens="Each wetland named here: "+wetlandsNames+ ", is characterized by these information: "+info+".";
		return mens;
	}
	
	public static String wetlandMinFlowers() {
		String mens="";
		int min = 0;
		String wetMinFlowers=null;
		for (int i=0; (i<=wetlands.length); i++){
		if (Wetland.countFlowers()>=min) {
			wetMinFlowers = wetlands[i].getName();
		}
		}
		mens="The wetland with the least amount of flowers is "+wetMinFlowers+".";
		return mens;
	}

	public static String wetlandsSpecies(String s) {
		String mens="";
		ArrayList<String>wetSpe = new ArrayList<String>();
		for (int i=0; (i<=wetlands.length); i++){
			if (Wetland.wetlandSpecies(s)==true){
				wetSpe.add(wetlands[i].getName());
			}
		}
		mens="The species"+s+"can be found in the following wetlands: "+wetSpe+".";
		return mens;
	}

	public static String wetlandMaxAnimals() {
		String mens="";
		int max = 0;
		String wetMaxAnimals=null;
		for (int i=0; (i<=wetlands.length); i++){
		if (Wetland.countAnimals()<=max) {
			wetMaxAnimals = wetlands[i].getName();
		}
		}
		mens="The wetland with the biggest amount of animals is "+wetMaxAnimals+".";
		return mens;
	}

}
