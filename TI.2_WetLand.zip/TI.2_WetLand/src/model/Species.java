package model;

public class Species {
	//atributos
	private String name;
	private String scientificName;
	private boolean migratory;
	private SpeciesType type;
	
	//modulos
	public enum SpeciesType{
		LANDFLOWER,
		AQUATICFLOWER,
		BIRD,
		MAMMAL,
		AQUATIC
	}
	
	public Species(String name, String scientificName, boolean migratory, int type) {
		this.name=name;
		this.scientificName=scientificName;
		this.migratory=migratory;
		
		switch(type) {
		case 1:
			this.type=SpeciesType.LANDFLOWER;
			break;
		case 2:
			this.type=SpeciesType.AQUATICFLOWER;
			break;
		case 3:
			this.type=SpeciesType.BIRD;
			break;
		case 4:
			this.type=SpeciesType.MAMMAL;
			break;
		case 5:
			this.type=SpeciesType.AQUATIC;
			break;
			
		}
		}
	
	public String getName() {
		return name;
		}
		
	public void setName(String name) {
		this.name = name;
	    }
	
	public String getScientificName() {
		return scientificName;
		}
		
	public void setScientificName(String scientificName) {
		this.scientificName = scientificName;
	    }
	
	public boolean getMigratory() {
		return migratory;
		}
		
	public void setMigratory(boolean migratory) {
		this.migratory = migratory;
	    }
	
	public String getType() {
		return type.toString();
		}
		
	public void setType(SpeciesType type) {
		this.type = type;
	    }

}
