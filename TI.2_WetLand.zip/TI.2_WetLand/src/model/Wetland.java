package model;

public class Wetland {
	public static final int MAXSPECIES=50000;
	public static final int MAXEVENTS=1000;
	
	//atributos
	private String name;
	private boolean urban;
	private String location;
	private boolean publ;
	private double surface;
	private String picture;
	private boolean protect;
	

	//relaciones
	private Species[] species;
	private Event[] events;
	
	//modelos
	public Wetland(String name, boolean urban, String location, boolean publ, double surface, String picture, boolean protect) {
		this.name=name;
		this.urban=urban;
		this.location=location;
		this.publ=publ;
		this.surface=surface;
		this.picture=picture;
		this.protect=protect;
		this.species=new Species[MAXSPECIES];
		this.events=new Event[MAXEVENTS];
	}
	
	public String getName() {
		return name;
		}
		
	public void setName(String name) {
		this.name = name;
	    }
	
	public boolean getUrban() {
		return urban;
		}
		
	public void setUrban(boolean urban) {
		this.urban = urban;
	    }
	
	public String getLocation() {
		return location;
		}
		
	public void setLocation(String location) {
		this.location = location;
	    }
	
	public boolean getPublic() {
		return publ;
		}
		
	public void setPublic (boolean publ) {
		this.publ = publ;
	    }
	
	public double getSurface() {
		return surface;
		}
		
	public void setSurface (double surface) {
		this.surface = surface;
	    }
	
	public String getPicture() {
		return picture;
		}
		
	public void setPicture(String picture) {
		this.picture = picture;
	    }
	
	public boolean getProtect() {
		return protect;
		}
		
	public void setProtect (boolean protect) {
		this.protect = protect;
	    }
	
	public boolean existSpecies(String name){
		boolean resultado=false;
		for(int i=0;i<MAXSPECIES && resultado==false; i++){
			if(species[i]!=null && species[i].getName().equals(name))
				resultado=true;
			}
		return resultado;
	   }
	
	public String addSpecies(String n, String sn, boolean mig, int t){
		boolean continuar=true;
	    String message="Species registered correctly";
	    boolean exist=existSpecies(n);
	    if (exist==true)
	       message="This species already exists.";
	    else
	    {
	      for (int i=0;(i<MAXSPECIES) && continuar;i++){
	        if (species[i]==null){
	        	species[i]=new Species(n,sn,mig,t);
	           continuar=false;}
	      }
	      if(continuar==true)
	         message="Array of species is full";
	    }
	    return message;
	   }
	
	public Species[] getSpecies() {
        return species;
    }
	
	public void setSpecies(Species[] species) {
        this.species = species;
    }
	
	public boolean existEvent(String name){
		boolean resultado=false;
		for(int i=0;i<MAXEVENTS && resultado==false; i++){
			if(events[i]!=null && events[i].getName().equals(name))
				resultado=true;
			}
		return resultado;
	   }
	
	public String addEvents(String n, int t, int d, int m, int y, String org, double val, String desc){
		boolean continuar=true;
	    String message="Event registered correctly. ";
	    boolean exist=existEvent(n);
	    if (exist==true)
	       message="This event already exists.";
	    else
	    {
	      for (int i=0;(i<MAXSPECIES) && continuar;i++){
	        if (events[i]==null){
	        	events[i]=new Event(n,t, d, m, y, org, val, desc);
	        	continuar=false;}
	      }
	      if(continuar==true)
	         message="Array of events is full";
	    }
	    return message;
	   }
	
	public Event[] getEvents() {
        return events;
    }
	
	public void setEvents(Event[] events) {
        this.events = events;
    }

}
