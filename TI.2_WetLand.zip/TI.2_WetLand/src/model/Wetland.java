package model;

public class Wetland {
	public static final int MAXSPECIES=100;
	public static final int MAXEVENTS=100;
	
	//atributos
	private String name;
	private boolean urban;
	private String location;
	private boolean publ;
	private double surface;
	private String picture;
	private boolean protect;
			
	//relaciones
	private static Species[] species;
	private static Event[] events;
	
	//modulos
	public Wetland(String name, boolean urban, String location, boolean publ, double surface, String picture, boolean protect) {
		this.name=name;
		this.urban=urban;
		this.location=location;
		this.publ=publ;
		this.surface=surface;
		this.picture=picture;
		this.protect=protect;
		Wetland.species=new Species[MAXSPECIES];
		Wetland.events=new Event[MAXEVENTS];
	}
	
	public String getName() {
		return name;
		}
		
	public void setName(String name) {
		this.name = name;
	    }
	
	public boolean getUrban() {
		return urban;
		}
		
	public void setUrban(boolean urban) {
		this.urban = urban;
	    }
	
	public String getLocation() {
		return location;
		}
		
	public void setLocation(String location) {
		this.location = location;
	    }
	
	public boolean getPublic() {
		return publ;
		}
		
	public void setPublic (boolean publ) {
		this.publ = publ;
	    }
	
	public double getSurface() {
		return surface;
		}
		
	public void setSurface (double surface) {
		this.surface = surface;
	    }
	
	public String getPicture() {
		return picture;
		}
		
	public void setPicture(String picture) {
		this.picture = picture;
	    }
	
	public boolean getProtect() {
		return protect;
		}
		
	public void setProtect (boolean protect) {
		this.protect = protect;
	    }
	
	public static boolean existSpecies(String name){
		boolean resultado=false;
		for(int i=0;i<MAXSPECIES && resultado==false; i++){
			if(species[i]!=null && species[i].getName().equals(name))
				resultado=true;
			}
		return resultado;
	   }
	
	public static String addSpecies(String n, String sn, boolean mig, int t){
		boolean continuar=true;
	    String message="Species registered correctly";
	    boolean exist=existSpecies(n);
	    if (exist==true)
	       message="This species already exists.";
	    else
	    {
	      for (int i=0;(i<MAXSPECIES) && continuar;i++){
	        if (species[i]==null){
	        	species[i]=new Species(n,sn,mig,t);
	           continuar=false;}
	      }
	      if(continuar==true)
	         message="Array of species is full";
	    }
	    return message;
	   }
	
	public Species[] getSpecies() {
        return species;
    }
	
	public void setSpecies(Species[] species) {
        Wetland.species = species;
    }
	
	public static boolean existEvent(String name){
		boolean resultado=false;
		for(int i=0;i<MAXEVENTS && resultado==false; i++){
			if(events[i]!=null && events[i].getName().equals(name))
				resultado=true;
			}
		return resultado;
	   }
	
	public static String addEvent(String n, int t, int d, int m, int y, String org, double val, String desc){
		boolean continuar=true;
	    String message="Event registered correctly. ";
	    boolean exist=existEvent(n);
	    if (exist==true)
	       message="This event already exists.";
	    else
	    {
	      for (int i=0;(i<MAXSPECIES) && continuar;i++){
	        if (events[i]==null){
	        	events[i]=new Event(n,t, d, m, y, org, val, desc);
	        	continuar=false;}
	      }
	      if(continuar==true)
	         message="Array of events is full";
	    }
	    return message;
	   }
	
	public static Event[] getEvents() {
        return events;
    }
	
	public void setEvents(Event[] events) {
        Wetland.events = events;
    }
	
	public static int countMaint(int y) {
		int count=0;
		for(int i=0; (i<=events.length); i++) {
				if(events[i].getType().equals("MAINTENANCE") && events[i].getDate().getYear()==y) {
					count++;
				}
		}
		return count;	
	}
	
	public static String infoWetland(Wetland w) {
		String mens="No info";
		String n=w.getName();
		boolean u=w.getUrban();
		String area;
		if (u) {area="urban";}
		else {area="rural";}
		String l=w.getLocation();
		boolean p=w.getPublic();
		String type;
		if (p) {type="public";}
		else {type="private";}
		double s=w.getSurface();
		String url=w.getPicture();
		boolean prot=w.getProtect();
		String reg;
		if (prot) {reg="area protected";}
		else {reg="not declared area protected";}
		String sp=w.getSpecies().toString();	
		mens=n+", "+area+", "+l+", "+type+", "+s+", "+url+", "+reg+", "+sp+"///";
		return mens;
		}
	
	public static int countFlowers() {
		int count=0;
		for(int i=0; (i<=species.length); i++) {
				if(species[i].getType().equals("LANDFLOWER") || species[i].getType().equals("AQUATICFLOWER")) {
					count++;
				}
		}
		return count;
	}
	
	public static boolean wetlandSpecies(String s) {
		boolean aux=false;
		for(int i=0; (i<=species.length); i++) {
			if(species[i].getName().equals(s)) {
				aux=true;
			}
		}
		return aux;
	}

	public static int countAnimals() {
		int count=0;
		for(int i=0; (i<=species.length); i++) {
				if(species[i].getType().equals("BIRD") || species[i].getType().equals("MAMMAL") || species[i].getType().equals("AQUATIC")) {
					count++;
				}
		}
		return count;
	}

}
