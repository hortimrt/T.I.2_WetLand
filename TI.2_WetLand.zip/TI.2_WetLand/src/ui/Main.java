package ui;
import java.util.Scanner;
import model.*;
	
public class Main {
	public static Scanner lt=new Scanner(System.in);
	public static void main(String[] args){
		int option=0;
		Wetland obj=newWetland();
		
		System.out.println("Do you want to register a new species in this wetland ? 1=Yes 2=No");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	newSpecies();
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        System.out.println("Do you want to register a new event in this wetland ? 1=Yes 2=No");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	newEvent();
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        System.out.println("Enter a year: ");
        int year=lt.nextInt();
        String m=numMaintenance(obj,year);
        System.out.println(m);
        }
	
	public static Wetland newWetland(){
		System.out.println("Enter the name of the wetland: ");
		String name=lt.nextLine();
		System.out.println("Is it urban (yes or no, if it's rural) ?");
		String rep=lt.nextLine();
		boolean urban;
		if (rep.equalsIgnoreCase("yes")) {
			urban=true;
			}
		else {
			urban=false;
			}
		System.out.println("Enter its location (name of the township or the neighborhood): ");
		String location=lt.nextLine();
		System.out.println("Is it public (yes or no, if it's private) ?");
		String r=lt.nextLine();
		boolean publ;
		if (r.equalsIgnoreCase("yes")) {
			publ=true;
			}
		else {
			publ=false;
			}
		System.out.println("Enter its surface (in km2):  ");
		double surface=lt.nextDouble();
		lt.nextLine();
		System.out.println("Add the URL of a picture: ");
		String picture=lt.nextLine();
		System.out.println("Is it declared area protected ?");
		String re=lt.nextLine();
		boolean protect;
		if (re.equalsIgnoreCase("yes")) {
			protect=true;
			}
		else {
			protect=false;
			}
		Wetland w=new Wetland(name, urban, location, publ, surface, picture, protect);
		return w;
		    }
	
	public static Species newSpecies(){
		System.out.println("Enter the name of the species: ");
		String name=lt.nextLine();
		System.out.println("Enter its scientific name: ");
		String scname=lt.nextLine();
		System.out.println("Is it migratory (yes or no) ?");
		String r=lt.nextLine();
		boolean mig;
		if (r.equalsIgnoreCase("yes")) {
			mig=true;
			}
		else {
			mig=false;
			}
		System.out.println("Enter its type (1=LANDFLOWER, 2=AQUATICFLOWER, 3=BIRD, 4=MAMMAL, 5=AQUATIC): ");
		int t=lt.nextInt();
		Species s=new Species(name, scname, mig, t);
		return s;
		    }
	
	public static Event newEvent(){
		System.out.println("Enter the name of the event: ");
		String name=lt.nextLine();
		lt.nextLine();
		System.out.println("Enter its type (1=MAINTENANCE, 2=SCHOOLVISIT, 3=IMPROVEMENT, 4=CELEBRATION): ");
		int t=lt.nextInt();
		System.out.println("Enter its day: ");
		int d=lt.nextInt();
		System.out.println("Enter its month: ");
		int m=lt.nextInt();
		System.out.println("Enter its year: ");
		int y=lt.nextInt();
		System.out.println("Enter the name of its organizer: ");
		String org=lt.nextLine();
		lt.nextLine();
		System.out.println("Enter its value: ");
		double val=lt.nextDouble();	
		System.out.println("Enter a short description: ");
		String desc=lt.nextLine();
		lt.nextLine();
		Event e=new Event(name, t, d, m, y, org, val, desc);
		return e;
		    }
	
	public static String numMaintenance(Wetland w, int y) {
		String mens;
		int count=0;
		if (w.getEvents()==null){
			mens="No event registered yet.";
		}
		else {
			for(int i=0; (i<=w.getEvents().length); i++) {
				if(w.getEvents()[i].getType().equals("MAINTENANCE") && w.getEvents()[i].getDate().getYear()==y) {
					count++;
				}
		}
			mens="For wetland "+w.getName()+ ", "+count+  " maintenance operations occurred in "+y+"." ;	
		}
		return mens;
	}
	
	public static String infoWetland(Wetland w) {
		String mens="No info";
		String n=w.getName();
		boolean u=w.getUrban();
		String area;
		if (u) {area="urban";}
		else {area="rural";}
		String l=w.getLocation();
		boolean p=w.getPublic();
		String type;
		if (p) {type="public";}
		else {type="private";}
		double s=w.getSurface();
		String url=w.getPicture();
		boolean prot=w.getProtect();
		String reg;
		if (prot) {reg="area protected";}
		else {reg="not declared area protected";}
		String sp=w.getSpecies().toString();	
		mens="The wetland " +n+" is caracterized by all these informations: "+area+", "+l+", "+type+", "+s+", "+url+", "+reg+", "+sp;
		return mens;
		}
		
	}
