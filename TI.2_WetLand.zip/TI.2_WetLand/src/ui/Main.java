package ui;
import java.util.Scanner;

import model.*;
	
public class Main {
	public static Scanner lt=new Scanner(System.in);
	
	public static Town town=new Town();
	
	public static void main(String[] args){
		int option=0;
		
		System.out.println("Do you want to register a new wetland ? 1=Yes 2=No");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	newWetland();
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        System.out.println("Do you want to register a new species in this wetland ? 1=Yes 2=No");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	newSpecies();
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        System.out.println("Do you want to register a new event in this wetland ? 1=Yes 2=No");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	newEvent();
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        System.out.println("Do you want to discover the number of maintenance operations realized in a year ? 1=Yes 2=No");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	System.out.println("Type a year: ");
        	int y=lt.nextInt();
        	countAllMaint(y);
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        System.out.println("Do you want to know more about each weatland ? 1=Yes 2=No");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	infoAllWetlands();
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        System.out.println("To discover which wetland holds the least amount of flowers, type 1. To skip this, type 2. ");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	wetlandMinFlowers();
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        System.out.println("To locate a particular species, type 1. To skip this, type 2.");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	System.out.println("Type the name of a species: ");
        	String s=lt.nextLine();
        	wetlandsSpecies(s);
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        System.out.println("To discover which wetland holds the biggest amount of animals, type 1. To end, type 2. ");
        option=lt.nextInt();
        lt.nextLine();
        switch (option){
        case 1:{
        	wetlandMaxAnimals();
        	break;
        }
        case 2:{
        	System.out.println("OK,let's move on then");
        	break;
        }
        }
        }
     
	
	public static void newWetland(){
		System.out.println("Enter the name of the wetland: ");
		String name=lt.nextLine();
		System.out.println("Is it urban (yes or no, if it's rural) ?");
		String rep=lt.nextLine();
		boolean urban;
		if (rep.equalsIgnoreCase("yes")) {
			urban=true;
			}
		else {
			urban=false;
			}
		System.out.println("Enter its location (name of the township or the neighborhood): ");
		String location=lt.nextLine();
		System.out.println("Is it public (yes or no, if it's private) ?");
		String r=lt.nextLine();
		boolean publ;
		if (r.equalsIgnoreCase("yes")) {
			publ=true;
			}
		else {
			publ=false;
			}
		System.out.println("Enter its surface (in km2):  ");
		double surface=lt.nextDouble();
		lt.nextLine();
		System.out.println("Add the URL of a picture: ");
		String picture=lt.nextLine();
		System.out.println("Is it declared area protected ?");
		String re=lt.nextLine();
		boolean protect;
		if (re.equalsIgnoreCase("yes")) {
			protect=true;
			}
		else {
			protect=false;
			}
		String message=town.addWetland(name, urban, location, publ, surface, picture, protect);
		System.out.println(message);
		    }
	
	public static void newSpecies(){
		System.out.println("Enter the name of the species: ");
		String name=lt.nextLine();
		System.out.println("Enter its scientific name: ");
		String scname=lt.nextLine();
		System.out.println("Is it migratory (yes or no) ?");
		String r=lt.nextLine();
		boolean mig;
		if (r.equalsIgnoreCase("yes")) {
			mig=true;
			}
		else {
			mig=false;
			}
		System.out.println("Enter its type (1=LANDFLOWER, 2=AQUATICFLOWER, 3=BIRD, 4=MAMMAL, 5=AQUATIC): ");
		int t=lt.nextInt();
		System.out.println("Enter the name of the wetland which contains this species: ");
		String wetlandSpecies=lt.nextLine();
		String message=town.newSpecies(wetlandSpecies, name, scname, mig, t);
		System.out.println(message);
		    }
	
	public static void newEvent(){
		System.out.println("Enter the name of the event: ");
		String name=lt.nextLine();
		lt.nextLine();
		System.out.println("Enter its type (1=MAINTENANCE, 2=SCHOOLVISIT, 3=IMPROVEMENT, 4=CELEBRATION): ");
		int t=lt.nextInt();
		System.out.println("Enter its day: ");
		int d=lt.nextInt();
		System.out.println("Enter its month: ");
		int m=lt.nextInt();
		System.out.println("Enter its year: ");
		int y=lt.nextInt();
		System.out.println("Enter the name of its organizer: ");
		String org=lt.nextLine();
		lt.nextLine();
		System.out.println("Enter its value: ");
		double val=lt.nextDouble();	
		System.out.println("Enter a short description: ");
		String desc=lt.nextLine();
		System.out.println("Enter the name of the wetland which contains this event: ");
		String wetlandEvent=lt.nextLine();
		String message=town.newEvent(wetlandEvent, name, t, d, m, y, org, val, desc);
		System.out.println(message);
		    }
	
	public static void countAllMaint(int year) {
		String message = Town.countAllMaint(year);
		System.out.println(message);
	}
	public static void infoAllWetlands() {
		String message = Town.infoAllWetlands();
		System.out.println(message);
	}
	public static void wetlandMinFlowers() {
		String message = Town.wetlandMinFlowers();
		System.out.println(message);
	}
	public static void wetlandsSpecies(String s) {
		String message = Town.wetlandsSpecies(s);
		System.out.println(message);
	}
	public static void wetlandMaxAnimals() {
		String message = Town.wetlandMaxAnimals();
		System.out.println(message);
	}
	}
